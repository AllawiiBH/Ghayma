# Ghayma (غيمة)

A simple GNOME app for downloading videos and audio, powered by
[yt-dlp](https://github.com/yt-dlp/yt-dlp) and FFmpeg. GTK4 + libadwaita, Wayland-first.

**Status:** v0.1 in development (skeleton). Not released.

- Free software: `GPL-3.0-or-later` (see `COPYING`)
- No accounts, no telemetry
- Planned distribution: Flatpak on Flathub

## Run from source (needs GTK4, libadwaita, PyGObject, ffmpeg)

    pip install yt-dlp yt-dlp-ejs
    PYTHONPATH=src python3 -m ghayma

## Tests (engine only, no GTK needed)

    pip install pytest yt-dlp
    python3 -m pytest tests

## Legal notice

You are responsible for respecting the terms of service of the websites you
download from and applicable copyright law. This project does not endorse
infringement.

---

**بالعربي:** تطبيق بسيط لـ GNOME لتحميل المقاطع والصوتيات بواجهة نظيفة،
مبني على yt-dlp وFFmpeg. برنامج حر برخصة GPL-3.0-or-later، بدون تتبع.
