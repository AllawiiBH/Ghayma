# SPDX-License-Identifier: GPL-3.0-or-later
"""Ghayma (غيمة): a simple GNOME front-end for downloading media with yt-dlp."""

__version__ = "0.1.0"
APP_ID = "io.gitlab.USERNAME.Ghayma"  # TODO: replace USERNAME with the GitLab username
