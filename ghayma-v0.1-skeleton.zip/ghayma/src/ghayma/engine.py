# SPDX-License-Identifier: GPL-3.0-or-later
"""GUI-independent download engine built on the yt-dlp Python API.

Nothing in this module imports GTK, so it can be tested headlessly.
User-facing text is NOT produced here: failures are reported as an
ErrorKind plus the raw technical detail, and the UI translates them.
"""

from __future__ import annotations

import enum
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import yt_dlp
from yt_dlp.utils import DownloadCancelled, DownloadError, ExtractorError


class Format(enum.Enum):
    MP4 = "mp4"
    MP3 = "mp3"
    ORIGINAL = "original"


class Quality(enum.Enum):
    BEST = 0
    P1080 = 1080
    P720 = 720
    P480 = 480


class State(enum.Enum):
    QUEUED = "queued"
    FETCHING = "fetching"
    DOWNLOADING = "downloading"
    PROCESSING = "processing"
    DONE = "done"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ErrorKind(enum.Enum):
    UNSUPPORTED_URL = "unsupported_url"
    PRIVATE_OR_LOGIN = "private_or_login"
    UNAVAILABLE = "unavailable"
    GEO_BLOCKED = "geo_blocked"
    NETWORK = "network"
    NO_FFMPEG = "no_ffmpeg"
    DISK = "disk"
    UNKNOWN = "unknown"


@dataclass
class MediaInfo:
    url: str
    title: str = ""
    uploader: str = ""
    duration: Optional[int] = None  # seconds
    thumbnail: Optional[str] = None  # URL


@dataclass
class DownloadJob:
    url: str
    fmt: Format = Format.MP4
    quality: Quality = Quality.BEST
    dest: Path = field(default_factory=lambda: Path.home() / "Downloads")
    state: State = State.QUEUED
    info: Optional[MediaInfo] = None
    progress: float = 0.0  # 0.0 .. 1.0
    speed: Optional[float] = None  # bytes/s
    eta: Optional[int] = None  # seconds
    filepath: Optional[Path] = None
    error_kind: Optional[ErrorKind] = None
    error_detail: str = ""
    _cancel: threading.Event = field(default_factory=threading.Event, repr=False)

    def cancel(self) -> None:
        self._cancel.set()


def build_format_selector(fmt: Format, quality: Quality) -> str:
    """Translate a (format, quality) preset into a yt-dlp format selector."""
    if fmt is Format.MP3:
        return "ba/b"
    if quality is Quality.BEST:
        return "bv*+ba/b"
    h = quality.value
    return f"bv*[height<={h}]+ba/b[height<={h}]/bv*+ba/b"


def build_ydl_options(job: DownloadJob, hook: Callable[[dict], None]) -> dict:
    opts: dict = {
        "format": build_format_selector(job.fmt, job.quality),
        "outtmpl": str(job.dest / "%(title).200B [%(id)s].%(ext)s"),
        "noplaylist": True,  # playlists arrive in v0.2
        "quiet": True,
        "no_warnings": True,
        "noprogress": True,
        "progress_hooks": [hook],
        "retries": 5,
        "fragment_retries": 5,
        "overwrites": False,
    }
    if job.fmt is Format.MP4:
        opts["merge_output_format"] = "mp4"
    elif job.fmt is Format.MP3:
        opts["postprocessors"] = [
            {"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}
        ]
    return opts


def classify_error(exc: BaseException) -> ErrorKind:
    """Map a yt-dlp exception to a coarse ErrorKind (heuristic on message text)."""
    msg = str(exc).lower()
    if "unsupported url" in msg:
        return ErrorKind.UNSUPPORTED_URL
    if any(s in msg for s in ("private video", "sign in", "log in", "login", "members-only", "confirm you")):
        return ErrorKind.PRIVATE_OR_LOGIN
    if any(s in msg for s in (
        "available in your country", "blocked it in your country",
        "geo restrict", "geo-restrict", "geoblock", "geo-block", "geo block",
    )):
        return ErrorKind.GEO_BLOCKED
    if any(s in msg for s in ("video unavailable", "has been removed", "does not exist", "404", "no longer available")):
        return ErrorKind.UNAVAILABLE
    if any(s in msg for s in ("ffmpeg", "ffprobe")):
        return ErrorKind.NO_FFMPEG
    if any(s in msg for s in ("no space left", "permission denied", "read-only file system")):
        return ErrorKind.DISK
    if any(s in msg for s in (
        "unable to download", "timed out", "temporary failure", "connection",
        "name or service not known", "network is unreachable",
    )):
        return ErrorKind.NETWORK
    return ErrorKind.UNKNOWN


def _info_from(url: str, data: dict) -> MediaInfo:
    return MediaInfo(
        url=url,
        title=data.get("title") or "",
        uploader=data.get("uploader") or data.get("channel") or "",
        duration=int(data["duration"]) if data.get("duration") else None,
        thumbnail=data.get("thumbnail"),
    )


def fetch_info(url: str) -> MediaInfo:
    """Fetch title/thumbnail/duration without downloading. Raises DownloadError."""
    opts = {"quiet": True, "no_warnings": True, "noplaylist": True, "skip_download": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        data = ydl.extract_info(url, download=False)
    return _info_from(url, data)


def run_job(job: DownloadJob, on_update: Callable[[DownloadJob], None]) -> None:
    """Run one job to completion on the CURRENT thread (call from a worker thread).

    `on_update` is invoked from this thread; the UI layer must marshal to the
    main loop (GLib.idle_add) itself.
    """

    def hook(d: dict) -> None:
        if job._cancel.is_set():
            raise DownloadCancelled()
        status = d.get("status")
        if status == "downloading":
            job.state = State.DOWNLOADING
            total = d.get("total_bytes") or d.get("total_bytes_estimate")
            if total:
                job.progress = min(d.get("downloaded_bytes", 0) / total, 1.0)
            job.speed = d.get("speed")
            job.eta = d.get("eta")
        elif status == "finished":
            job.state = State.PROCESSING
            job.speed = None
            job.eta = None
        on_update(job)

    try:
        job.dest.mkdir(parents=True, exist_ok=True)
        job.state = State.FETCHING
        on_update(job)
        with yt_dlp.YoutubeDL(build_ydl_options(job, hook)) as ydl:
            data = ydl.extract_info(job.url, download=True)
            if data:
                job.info = _info_from(job.url, data)
                final = data.get("requested_downloads") or []
                if final and final[0].get("filepath"):
                    job.filepath = Path(final[0]["filepath"])
        if job._cancel.is_set():
            job.state = State.CANCELLED
        else:
            job.state = State.DONE
            job.progress = 1.0
    except DownloadCancelled:
        job.state = State.CANCELLED
    except (DownloadError, ExtractorError) as exc:
        if job._cancel.is_set():
            job.state = State.CANCELLED
        else:
            job.state = State.FAILED
            job.error_kind = classify_error(exc)
            job.error_detail = str(exc)
    except OSError as exc:
        job.state = State.FAILED
        job.error_kind = ErrorKind.DISK
        job.error_detail = str(exc)
    except Exception as exc:  # last resort: never crash the UI thread
        job.state = State.FAILED
        job.error_kind = ErrorKind.UNKNOWN
        job.error_detail = f"{type(exc).__name__}: {exc}"
    finally:
        on_update(job)
