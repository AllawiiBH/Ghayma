# SPDX-License-Identifier: GPL-3.0-or-later
"""GTK4 + libadwaita front-end. v0.1 skeleton: paste link, pick preset, queue, notify.

NOTE: written without a GTK runtime available to the author's sandbox, so this
file has not been executed yet. Treat the first run on a real GNOME as the test.
"""

from __future__ import annotations

import queue
import sys
import threading
from gettext import gettext as _
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Adw, Gdk, Gio, GLib, Gtk  # noqa: E402

from . import APP_ID, __version__, engine  # noqa: E402

FORMATS = [(_("Video (MP4)"), engine.Format.MP4), (_("Audio (MP3)"), engine.Format.MP3),
           (_("Original format"), engine.Format.ORIGINAL)]
QUALITIES = [(_("Best"), engine.Quality.BEST), ("1080p", engine.Quality.P1080),
             ("720p", engine.Quality.P720), ("480p", engine.Quality.P480)]

ERROR_TEXT = {
    engine.ErrorKind.UNSUPPORTED_URL: _("This link is not supported."),
    engine.ErrorKind.PRIVATE_OR_LOGIN: _("This video is private or requires signing in."),
    engine.ErrorKind.UNAVAILABLE: _("This video is unavailable or was removed."),
    engine.ErrorKind.GEO_BLOCKED: _("This video is not available in your country."),
    engine.ErrorKind.NETWORK: _("Network problem. Check your connection and try again."),
    engine.ErrorKind.NO_FFMPEG: _("Media conversion tool (ffmpeg) is missing."),
    engine.ErrorKind.DISK: _("Could not write to the download folder."),
    engine.ErrorKind.UNKNOWN: _("Download failed."),
}


class JobRow(Adw.ActionRow):
    def __init__(self, job: engine.DownloadJob):
        super().__init__(title=GLib.markup_escape_text(job.url), title_lines=1)
        self.job = job
        self.bar = Gtk.ProgressBar(valign=Gtk.Align.CENTER, width_request=120)
        self.cancel_btn = Gtk.Button(icon_name="process-stop-symbolic", valign=Gtk.Align.CENTER,
                                     tooltip_text=_("Cancel"))
        self.cancel_btn.add_css_class("flat")
        self.cancel_btn.connect("clicked", lambda _b: self.job.cancel())
        self.add_suffix(self.bar)
        self.add_suffix(self.cancel_btn)
        self.refresh()

    def refresh(self) -> None:
        j = self.job
        if j.info and j.info.title:
            self.set_title(GLib.markup_escape_text(j.info.title))
        self.bar.set_fraction(j.progress)
        text = {
            engine.State.QUEUED: _("Waiting…"),
            engine.State.FETCHING: _("Reading link…"),
            engine.State.DOWNLOADING: _("Downloading…"),
            engine.State.PROCESSING: _("Processing…"),
            engine.State.DONE: _("Done"),
            engine.State.CANCELLED: _("Cancelled"),
            engine.State.FAILED: ERROR_TEXT.get(j.error_kind, ERROR_TEXT[engine.ErrorKind.UNKNOWN]),
        }[j.state]
        self.set_subtitle(GLib.markup_escape_text(text))
        finished = j.state in (engine.State.DONE, engine.State.FAILED, engine.State.CANCELLED)
        self.cancel_btn.set_visible(not finished)
        self.bar.set_visible(not finished)


class Window(Adw.ApplicationWindow):
    def __init__(self, app: "GhaymaApp"):
        super().__init__(application=app, title=_("Ghayma"), default_width=560, default_height=640)
        self.dest = Path(GLib.get_user_special_dir(GLib.UserDirectory.DIRECTORY_DOWNLOAD) or Path.home())
        self.jobs: "queue.Queue[tuple[engine.DownloadJob, JobRow]]" = queue.Queue()
        threading.Thread(target=self._worker, daemon=True).start()

        self.url_row = Adw.EntryRow(title=_("Link"))
        paste = Gtk.Button(icon_name="edit-paste-symbolic", valign=Gtk.Align.CENTER,
                           tooltip_text=_("Paste"))
        paste.add_css_class("flat")
        paste.connect("clicked", self._on_paste)
        self.url_row.add_suffix(paste)
        self.url_row.connect("entry-activated", self._on_download)

        self.fmt_row = Adw.ComboRow(title=_("Format"), model=Gtk.StringList.new([n for n, _v in FORMATS]))
        self.q_row = Adw.ComboRow(title=_("Quality"), model=Gtk.StringList.new([n for n, _v in QUALITIES]))
        self.fmt_row.connect("notify::selected", self._on_format_changed)

        self.folder_row = Adw.ActionRow(title=_("Save to"), subtitle=str(self.dest), activatable=True)
        self.folder_row.add_suffix(Gtk.Image.new_from_icon_name("folder-symbolic"))
        self.folder_row.connect("activated", self._on_pick_folder)

        group = Adw.PreferencesGroup()
        for r in (self.url_row, self.fmt_row, self.q_row, self.folder_row):
            group.add(r)

        btn = Gtk.Button(label=_("Download"), halign=Gtk.Align.CENTER)
        btn.add_css_class("suggested-action")
        btn.add_css_class("pill")
        btn.connect("clicked", self._on_download)

        self.list = Gtk.ListBox(selection_mode=Gtk.SelectionMode.NONE)
        self.list.add_css_class("boxed-list")
        self.list.set_visible(False)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18, margin_top=18,
                      margin_bottom=18, margin_start=12, margin_end=12)
        for w in (group, btn, self.list):
            box.append(w)
        clamp = Adw.Clamp(maximum_size=600, child=box)
        scroller = Gtk.ScrolledWindow(child=clamp, vexpand=True)
        view = Adw.ToolbarView(content=scroller)
        view.add_top_bar(Adw.HeaderBar())
        self.set_content(view)

    def _on_format_changed(self, *_args) -> None:
        # Quality is meaningless for audio-only / original format.
        self.q_row.set_sensitive(FORMATS[self.fmt_row.get_selected()][1] is engine.Format.MP4)

    def _on_paste(self, *_args) -> None:
        clip = Gdk.Display.get_default().get_clipboard()

        def done(cb, res):
            try:
                text = cb.read_text_finish(res)
            except GLib.Error:
                return
            if text:
                self.url_row.set_text(text.strip())

        clip.read_text_async(None, done)

    def _on_pick_folder(self, *_args) -> None:
        dlg = Gtk.FileDialog(title=_("Choose download folder"))

        def done(d, res):
            try:
                f = d.select_folder_finish(res)
            except GLib.Error:
                return
            if f and f.get_path():
                self.dest = Path(f.get_path())
                self.folder_row.set_subtitle(str(self.dest))

        dlg.select_folder(self, None, done)

    def _on_download(self, *_args) -> None:
        url = self.url_row.get_text().strip()
        if not url:
            return
        job = engine.DownloadJob(
            url=url,
            fmt=FORMATS[self.fmt_row.get_selected()][1],
            quality=QUALITIES[self.q_row.get_selected()][1],
            dest=self.dest,
        )
        row = JobRow(job)
        self.list.prepend(row)
        self.list.set_visible(True)
        self.url_row.set_text("")
        self.jobs.put((job, row))

    def _worker(self) -> None:
        while True:  # one download at a time in v0.1
            job, row = self.jobs.get()
            engine.run_job(job, lambda j, r=row: GLib.idle_add(self._on_update, j, r))

    def _on_update(self, job: engine.DownloadJob, row: JobRow) -> bool:
        row.refresh()
        if job.state in (engine.State.DONE, engine.State.FAILED):
            self.get_application().notify_finished(job)
        return False  # run once


class GhaymaApp(Adw.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.DEFAULT_FLAGS)
        act = Gio.SimpleAction.new("open-folder", GLib.VariantType.new("s"))
        act.connect("activate", self._open_folder)
        self.add_action(act)

    def do_activate(self) -> None:
        (self.props.active_window or Window(self)).present()

    def notify_finished(self, job: engine.DownloadJob) -> None:
        n = Gio.Notification.new(_("Ghayma"))
        if job.state is engine.State.DONE:
            n.set_body(_("Download finished: %s") % (job.info.title if job.info else job.url))
            n.add_button_with_target(_("Open folder"), "app.open-folder",
                                     GLib.Variant.new_string(str(job.dest)))
        else:
            n.set_body(ERROR_TEXT.get(job.error_kind, ERROR_TEXT[engine.ErrorKind.UNKNOWN]))
        self.send_notification(None, n)

    def _open_folder(self, _action, param) -> None:
        Gtk.FileLauncher.new(Gio.File.new_for_path(param.get_string())).launch(
            self.props.active_window, None, None)


def main() -> int:
    return GhaymaApp().run(sys.argv)
