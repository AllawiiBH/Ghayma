# SPDX-License-Identifier: GPL-3.0-or-later
"""Offline engine tests. A local HTTP server serves a tiny generated video,
which yt-dlp's generic extractor can download (no internet needed)."""

import functools
import http.server
import shutil
import subprocess
import sys
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from ghayma import engine as e  # noqa: E402

needs_ffmpeg = pytest.mark.skipif(shutil.which("ffmpeg") is None, reason="ffmpeg not installed")


def test_format_selector():
    assert e.build_format_selector(e.Format.MP3, e.Quality.BEST) == "ba/b"
    assert e.build_format_selector(e.Format.MP4, e.Quality.BEST) == "bv*+ba/b"
    sel = e.build_format_selector(e.Format.MP4, e.Quality.P720)
    assert "height<=720" in sel and sel.endswith("bv*+ba/b")


@pytest.mark.parametrize(
    "msg,kind",
    [
        ("ERROR: Unsupported URL: https://x.y", e.ErrorKind.UNSUPPORTED_URL),
        ("ERROR: Private video. Sign in if you've been granted access", e.ErrorKind.PRIVATE_OR_LOGIN),
        ("ERROR: Video unavailable", e.ErrorKind.UNAVAILABLE),
        ("The uploader has not made this video available in your country", e.ErrorKind.GEO_BLOCKED),
        ("ERROR: Unable to download webpage: <urlopen error timed out>", e.ErrorKind.NETWORK),
        ("ERROR: Postprocessing: ffprobe and ffmpeg not found", e.ErrorKind.NO_FFMPEG),
        ("[Errno 28] No space left on device", e.ErrorKind.DISK),
        ("something weird", e.ErrorKind.UNKNOWN),
    ],
)
def test_classify_error(msg, kind):
    assert e.classify_error(Exception(msg)) == kind


@pytest.fixture(scope="module")
def server(tmp_path_factory):
    root = tmp_path_factory.mktemp("srv")
    if shutil.which("ffmpeg"):
        subprocess.run(
            ["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "testsrc=size=160x90:rate=10",
             "-f", "lavfi", "-i", "sine=frequency=440", "-t", "2", "-c:v", "libx264",
             "-pix_fmt", "yuv420p", "-c:a", "aac", str(root / "clip.mp4")],
            check=True,
        )
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(root))
    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{httpd.server_address[1]}"
    httpd.shutdown()


@needs_ffmpeg
def test_download_original_mp4(server, tmp_path):
    job = e.DownloadJob(url=f"{server}/clip.mp4", fmt=e.Format.ORIGINAL, dest=tmp_path)
    updates = []
    e.run_job(job, lambda j: updates.append(j.state))
    assert job.state is e.State.DONE, job.error_detail
    assert job.filepath and job.filepath.exists()
    assert e.State.FETCHING in updates and updates[-1] is e.State.DONE


@needs_ffmpeg
def test_download_mp3_conversion(server, tmp_path):
    job = e.DownloadJob(url=f"{server}/clip.mp4", fmt=e.Format.MP3, dest=tmp_path)
    e.run_job(job, lambda j: None)
    assert job.state is e.State.DONE, job.error_detail
    assert job.filepath and job.filepath.suffix == ".mp3" and job.filepath.exists()


def test_unsupported_url_fails_cleanly(tmp_path):
    job = e.DownloadJob(url="not a url at all", dest=tmp_path)
    e.run_job(job, lambda j: None)
    assert job.state is e.State.FAILED
    assert job.error_kind is not None


@needs_ffmpeg
def test_cancel_before_start(server, tmp_path):
    job = e.DownloadJob(url=f"{server}/clip.mp4", fmt=e.Format.ORIGINAL, dest=tmp_path)
    job.cancel()
    e.run_job(job, lambda j: None)
    assert job.state is e.State.CANCELLED
